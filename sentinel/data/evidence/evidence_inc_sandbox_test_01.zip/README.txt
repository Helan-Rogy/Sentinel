AEGIS SENTINEL FORENSIC EVIDENCE BUNDLE
=========================================
Incident ID     : inc_sandbox_test_01
Created         : 2026-10-26 18:44:43.073077+00:00
Status          : awaiting_approval
Target Process  : ransom_payload.exe (PID: 5555)
Risk Level      : critical
Affected Files  : 0
Canary Hits     : 0

Contents:
- incident_dossier.json   : Complete schema dump with decision logs and telemetry
- entropy_telemetry.csv   : Per-file Shannon entropy and chi-square distribution
- canary_tripwires.json   : Exact timestamps of tripped decoy files
- network_connections.json: Extracted IP/port/proto connection table
- traffic_capture.pcap    : Raw packet capture file compatible with Wireshark
- dropped_artifacts/      : Recovered dropped scripts, notes, and locked samples
