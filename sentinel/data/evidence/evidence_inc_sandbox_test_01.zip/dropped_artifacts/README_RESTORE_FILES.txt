========================================================================
                    YOUR FILES HAVE BEEN ENCRYPTED                      
========================================================================
All your documents, spreadsheets, and databases have been locked.
Incident Reference ID: inc_sandbox_test_01
To recover your data, contact support via Tor Browser.
========================================================================
