========================================================================
                    YOUR FILES HAVE BEEN ENCRYPTED                      
========================================================================
All your documents, spreadsheets, and databases have been locked.
Incident Reference ID: inc_1d96d3b6bd
To recover your data, contact support via Tor Browser.
========================================================================
