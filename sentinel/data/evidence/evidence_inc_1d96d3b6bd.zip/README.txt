AEGIS SENTINEL FORENSIC EVIDENCE BUNDLE
=========================================
Incident ID     : inc_1d96d3b6bd
Created         : 2026-10-26 18:29:11.974889+00:00
Status          : open
Target Process  : blackcat_encryptor.exe (PID: 4812)
Risk Level      : critical
Affected Files  : 42
Canary Hits     : 1

Contents:
- incident_dossier.json   : Complete schema dump with decision logs and telemetry
- entropy_telemetry.csv   : Per-file Shannon entropy and chi-square distribution
- canary_tripwires.json   : Exact timestamps of tripped decoy files
- network_connections.json: Extracted IP/port/proto connection table
- traffic_capture.pcap    : Raw packet capture file compatible with Wireshark
- dropped_artifacts/      : Recovered dropped scripts, notes, and locked samples
